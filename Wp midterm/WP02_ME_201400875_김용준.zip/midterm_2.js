var file = document.getElementById("fina").value;
var scala = document.getElementById("scna").value;

console.log(file);
console.log(scala);

function filename(file) {
  if(file=="") {
    alert
  }
}

function scalaname() {

}
